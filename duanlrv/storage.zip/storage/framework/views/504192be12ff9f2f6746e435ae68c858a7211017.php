
<section class="shopping-cart spad delete" data-url="<?php echo e(route('deleteCart')); ?>">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                <?php if(session()->has('message')): ?>
			                    <div class="alert alert-success">
			                        <?php echo session()->get('message'); ?>

			                    </div>
			                <?php elseif(session()->has('error')): ?>
			                     <div class="alert alert-danger">
			                        <?php echo session()->get('error'); ?>

			                    </div>
			                <?php endif; ?>
                    <div class="cart-table">
                        <table class="update_cart_url" data-url="<?php echo e(route('updateCart')); ?>" >
                            <thead>
                                <tr>
                                    <th>Hình ảnh</th>
                                    <th class="p-name">Sản phẩm</th>
                                    <th>Đơn giá</th>
                                    <th>Số lượng</th>
                                    <th>Tổng</th>
                                    <?php 
                                    $count=0;
                                    ?>  
                                    <?php if(session('cart')==true): ?>
                                    <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php 
                                    $count += $CartItem['quantity'];
                                    ?> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?> 
                                    <th><a href="#" class="removeCart">Xóa Giỏ Hàng</a> (<?php echo e($count); ?>)</th>
                                </tr>
                            </thead>
                            <!-- cart -->
                            <?php 
                            $total = 0;
                            ?>
                            <?php if(Session::has('cart')!=null): ?>
                            <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $CartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                            $total += $CartItem['price'] * $CartItem['quantity'];
                            ?>
                            <tbody>
                                <tr>
                                    <td class="cart-pic first-row">
                                    <?php if(json_decode($CartItem['images'])): ?>
                                        <img src="<?php echo e(asset('uploads')); ?>/<?php echo e(json_decode($CartItem['images'])[0]); ?>" width="150px"alt="">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('uploads')); ?>/<?php echo e($CartItem['images']); ?>" width="150px" alt="">
                                    <?php endif; ?>
                                    </td>
                                    <td class="cart-title first-row">
                                        <h5><?php echo e($CartItem['name']); ?></h5>
                                    </td>
                                    <td class="p-price first-row"><?php echo e(number_format($CartItem['price'])); ?>đ</td>
                                    <td class="qua-col first-row">
                                        <div class="quantity">
                                            <div class="pro-qty">
                                                <!-- <input type="number" value="<?php echo e($CartItem['quantity']); ?>" min="1" class="quatity"> -->
                                                <span class="dec qtybtn">-</span>
                                                <input type="text" value="<?php echo e($CartItem['quantity']); ?>" min="1" class="quatity" disabled>
                                                <span class="inc qtybtn">+</span>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="total-price first-row"><?php echo e(number_format($CartItem['quantity'] * $CartItem['price'])); ?>đ</td>
                                    <td class="close-td first-row"><i class="cart_update ti-save" data-id='<?php echo e($id); ?>' onclick=""></i></td>
                                    <td class="close-td first-row"><i data-id='<?php echo e($id); ?>' class="ti-close deleteCart"></i></td>
                                </tr>
                            </tbody>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                <?php endif; ?>
                              <!-- end cart -->
                                
                        </table>
                    </div>
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="cart-buttons">
                                <a href="<?php echo e(route('products')); ?>" class="primary-btn continue-shop">Mua tiếp</a>
                                <!-- <a href="#" class="primary-btn up-cart">Cập nhật giỏ hàng</a> -->
                            </div>
                            <div class="discount-coupon">
                                <h6>Mã giảm giá</h6>
                                <form action="<?php echo e(url('/check-coupon')); ?>" method="post" class="coupon-form">
                                    <?php echo csrf_field(); ?>
                                    <?php if(Session::get('coupon')==null): ?>
                                    <input type="text" placeholder="Nhập mã giảm giá" name="coupon">
                                    <button type="submit" class="site-btn coupon-btn">Giảm ngay</button>
                                    <?php endif; ?>
                                </form>
                                <td>
                                    <?php if(Session::get('coupon')): ?>
                                    <a class="btn btn-warning " style="width:100%; font-size:1vw" href="<?php echo e(url('/unset-coupon')); ?>">Xóa mã khuyến mãi</a>
                                    <?php endif; ?>
                                </td>
                            </div>
                        </div>
                        <div class="col-lg-4 offset-lg-4">
                            <div class="proceed-checkout">
                                <ul>
                                
                                    <li class="cart-total">Tổng  <span> <?php echo e(number_format($total,0,',','.')); ?>Đ</span></li>
                                    <li class="subtotal"> 
                                    <?php if(Session::get('coupon')): ?>
										<li>
											
												<?php $__currentLoopData = Session::get('coupon'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cou): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<?php if($cou['coupon_condition'] == 1): ?>
														Mã giảm : <?php echo e($cou['coupon_number']); ?>%
														<p>
															<?php 
															$total_coupon = ($total*$cou['coupon_number'])/100;
															?>
														</p>
                                                        <li class="cart-total">Tổng  <span> <?php echo e(number_format($total - $total_coupon,0,',','.')); ?>Đ</span></li>
													<?php elseif($cou['coupon_condition']==2): ?>
														Mã giảm : <?php echo e(number_format($cou['coupon_number'],0,',','.')); ?>đ
														<p>
															<?php 
															$total_coupon = $total - $cou['coupon_number'];
															?>
														</p>														
                                                        <li class="cart-total">Tổng  <span> <?php echo e(number_format($total_coupon,0,',','.')); ?>Đ</span></li>
													<?php endif; ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</li>
									<?php endif; ?>
                                            
                                       
                                    </li>
                                </ul>
                                <a href="<?php echo e(route('checkout')); ?>" class="proceed-btn">Thanh toán</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
  
<script>
    jQuery(document).ready(function($) {
        var proQty = $('.pro-qty');
        proQty.addClass('dec qtybtn');
        proQty.addClass('inc qtybtn');
        proQty.on('click', '.qtybtn', function () {
            var $button = $(this);
            var oldValue = $button.parent().find('input').val();
            if ($button.hasClass('inc')) {
                var newVal = parseFloat(oldValue) + 1;
            } else if($button.hasClass('dec')){
                // Don't allow decrementing below zero
                if (oldValue > 1) {
                    var newVal = parseFloat(oldValue) - 1;
                } else {
                    newVal = 1;
                }
            }
            $button.parent().find('input').val(newVal);
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\datn\duanlrv\resources\views/Site/contentCart.blade.php ENDPATH**/ ?>