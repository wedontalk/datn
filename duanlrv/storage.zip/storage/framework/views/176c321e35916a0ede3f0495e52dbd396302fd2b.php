                                            <?php 
                                            $count=0;
                                            ?>  
                                            <?php if(session('cart')): ?>
                                            <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $CartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php 
                                             $count += $CartItem['quantity'];
                                             ?> 
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?> 
                                    <a href="#">
                                    <i class="icon_bag_alt"></i>
                                    <span id="cart_count"><?php echo e($count); ?></span>
                                </a>
                                <div class="cart-hover delete" data-url="<?php echo e(route('deleteCart')); ?>" >
                                    <div class="select-items" >
                                    <table>
                                        <tbody>
                                        <?php 
                                        $total = 0;
                                        
                                        ?>
                                        <?php if(Session::has('cart')!=null): ?>
                                        <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $CartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                        $total += $CartItem['price'] * $CartItem['quantity'];
                                        
                                        ?>
                                            <tr>
                                                <td class="si-pic">
                                                <?php if(json_decode($CartItem['images'])): ?>
                                                    <img src="<?php echo e(asset('uploads')); ?>/<?php echo e(json_decode($CartItem['images'])[0]); ?>" width="150px" alt="">
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('uploads')); ?>/<?php echo e($CartItem['images']); ?>" width="100px" alt="">
                                                <?php endif; ?>
                                                </td>
                                                <td class="si-text">
                                                    <div class="product-selected">
                                                        <h6><?php echo e($CartItem['name']); ?></h6>
                                                        <p><?php echo e(number_format($CartItem['price'])); ?>đ x <?php echo e($CartItem['quantity']); ?></p>
                                                    </div>
                                                </td>
                                                <td class="si-close">
                                                    <i class="ti-close deleteCart" data-id='<?php echo e($id); ?>'></i>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                    </div>
                                    <div class="select-total">
                                        <span>Tổng:</span>
                                        <h5><?php echo e(number_format($total)); ?>đ</h5>
                                    </div>
                                    <div class="select-button">
                                        <a href="<?php echo e(route('cartViews')); ?>" class="primary-btn view-card">Xem giỏ hàng</a>
                                        <a href="#" class="primary-btn checkout-btn">Thanh toán</a>
                                    </div>
                                </div>
                                <script>
    

//Xóa cart
    function deleteCart(event){
        event.preventDefault();
        let urldeleteCart= $('.delete').data('url');
        let id =$(this).data('id');
        alertify.confirm('Bạn có muốn xóa không?', function(result){
            if(result){
                $.ajax({
                    type:"GET",
                    url: urldeleteCart,
                    data: {id: id},
                    success: function (data) {
                            $('.content').html(data.contentCart);
                            $('#ajax_cart').html(data.cartquick);   
                            console.log(data);
                    },
                    error: function () {
                        
                    }
                })
            }
        alertify.success('Xóa Sản phẩm thành công!') 
        }, function(){ alertify.error('Hủy Xóa sản phẩm')});
    }



//các sự kiện
    $(function () {
        $(document).on('click','.deleteCart',deleteCart);
    });
   
</script><?php /**PATH C:\xampp\htdocs\datn\duanlrv\resources\views/Site/cartquick.blade.php ENDPATH**/ ?>