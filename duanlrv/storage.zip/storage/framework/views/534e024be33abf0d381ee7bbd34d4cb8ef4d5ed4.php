
<?php $__env->startSection('main'); ?>

    <!-- Breadcrumb Section Begin -->
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text product-more">
                        <a href="./index.html"><i class="fa fa-home"></i> Trang chủ</a>
                        <a href="./shop.html">Shop</a>
                        <span>Thanh toán</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section Begin -->
  
    <?php if(Route::has('login')): ?>
    <?php if(auth()->guard()->check()): ?>
    <!-- Shopping Cart Section Begin -->
    <section class="checkout-section spad">
        <div class="container">
        <form action="<?php echo e(URL::to('/save_checkout')); ?>" method="POST" class="checkout-form" formenctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="row">
                    <div class="col-lg-6">
                        <!-- <div class="checkout-content">
                            <a href="#" class="content-btn">Click Here To Login</a>
                        </div> -->

                        <h4>Chi tiết thanh toán</h4>
                        <div class="row">
                            <div class="col-lg-12">
                                <label for="fir">Họ và Tên<span>*</span></label>
                                <input type="text" id="fir" name="order_name" value="<?php echo e(Auth::user()->name); ?>" >
                                <?php $__errorArgs = ['order_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-warning" role="alert">
                                <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                           
                         
                    <div class="col-sm-12" >
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                    <label for="fir">Tỉnh - Thành phố<span>*</span></label>
                                        <select class="form-control choose input-sm city" name="id_thanhpho" id="city" >
                                            <option value="<?php echo e(old('id_thanhpho')); ?>">-----<?php echo e(__('Tỉnh - Thành phố')); ?>-----</option>
                                            <?php $__currentLoopData = $thanhpho; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option class="op-text" name="id_thanhpho" value="<?php echo e($t->matp); ?>"><?php echo e($t->name_thanhpho); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                        <?php $__errorArgs = ['id_thanhpho'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-warning" role="alert">
                                        <?php echo e($message); ?>

                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <label class="">Quận - Huyện</label>
                                        <select class="form-control input-sm choose province" name="id_quanhuyen" id="province" value="<?php echo e(old('id_quanhuyen')); ?>">
                                            <option value="<?php echo e(old('id_quanhuyen')); ?>" class="op-text" >-----<?php echo e(__('Chọn quận huyện')); ?>-----</option>
                                        </select>
                                        <?php $__errorArgs = ['id_quanhuyen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-warning" role="alert">
                                        <?php echo e($message); ?>

                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <label class="">Xã - phường</label>
                                        <select class="form-control input-sm wards" name="id_xaphuong" id="wards" >
                                            <option value="<?php echo e(old('id_xaphuong')); ?>" class="op-text">-----<?php echo e(__('Chọn xã phường')); ?>-----</option>
                                        </select>
                                        <?php $__errorArgs = ['id_xaphuong'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-warning" role="alert">
                                        <?php echo e($message); ?>

                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <label class="">Địa chỉ</label>
                                        <input type="text" class="form-control" name="order_address"  placeholder="địa chỉ cụ thể (địa chỉ nhà)" value="<?php echo e(old('order_address')); ?>">
                                        <?php $__errorArgs = ['order_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-warning" role="alert">
                                        <?php echo e($message); ?>

                                        </div> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-lg-6">
                                <label for="email">Email <span>*</span></label>
                                <input type="email" id="email" name="order_email" value="<?php echo e(Auth::user()->email); ?>">
                                <?php $__errorArgs = ['order_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-warning" role="alert">
                                        <?php echo e($message); ?>

                                        </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-lg-6">
                                <label for="phone">Số điện thoại<span>*</span></label>
                                <input type="text" id="phone" name="order_phone" value="0<?php echo e(Auth::user()->phone); ?>">
                                <?php $__errorArgs = ['order_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-warning" role="alert">
                                        <?php echo e($message); ?>

                                        </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-lg-12">
                                <label for="ghichu">Phương thức thanh toán<span></span></label>
                                <!-- <input class="form-check-input radio" type="radio" name="phuongthuc_thanhtoan" id="flexRadioDefault2" value="1" checked>
                                <label class="form-check-label" for="flexRadioDefault2">
                                    Thanh toán khi nhận hàng
                                </label> -->
                                <div class="form-check ">
                                <input class="form-check-input radio" type="radio" name="phuongthuc_thanhtoan" id="exampleRadios1" value="1" checked>
                                <label class="form-check-label" for="exampleRadios1" style="margin-left:50px">
                                    Thanh toán khi nhận hàng
                                </label>
                                </div>
                                <div class="form-check ">
                                <input class="form-check-input radio" type="radio" name="phuongthuc_thanhtoan" id="exampleRadios1" value="2" check>
                                <label class="form-check-label" for="exampleRadios1" style="margin-left:50px">
                                    Thanh toán online
                                </label>
                                </div>

                            </div>
                            <div class="col-lg-12">
                                <label for="ghichu">Ghi chú<span>*</span></label>
                                <textarea name="order_note" id="ghichu" cols="95" rows="10"></textarea>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <!-- <div class="checkout-content">
                            <input type="text" placeholder="Enter Your Coupon Code">
                        </div> -->
                        <div class="place-order">

                            <h4>Đơn hàng</h4>
                            <div class="order-total">
                                <ul class="order-table">
                                    <li>Sản phẩm <span></span></li>
                                    <?php 
                            $total = 0;
                            ?>
                            <?php if(Session::has('cart')!=null): ?>
                            <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $CartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                            $total += $CartItem['price'] * $CartItem['quantity'];
                            ?>
                            <li class="fw-normal"><?php echo e($CartItem['name']); ?> x <?php echo e($CartItem['quantity']); ?> <span><?php echo e(number_format($CartItem['quantity'] * $CartItem['price'])); ?>đ</span></li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                <?php endif; ?>
                              <!-- end cart -->
                              <!-- <li> <span class="mt-3">Tổng:   <?php echo e(number_format($total)); ?> </span></li> -->
                            </ul>
                            <!-- <input type="hidden" name="tong_tien" value="<?php echo e($total); ?>" readonly> -->
                            
                              
                                  <div class="row">
                                        <div class="col-lg-12">
                                            
                                            <!-- <div class="discount-coupon">
                                                <h6>Mã giảm giá</h6>
                                                <form action="<?php echo e(url('/check-coupon')); ?>" method="post" class="coupon-form">
                                                    <?php echo csrf_field(); ?>
                                                    <?php if(Session::get('coupon')==null): ?>
                                                    <input type="text" placeholder="Nhập mã giảm giá" name="coupon"style="width:63%; font-size:1vw">
                                                    <button type="submit" class="site-btn coupon-btn">Giảm ngay</button>
                                                    <?php endif; ?>
                                                    <?php if(Session::get('coupon')): ?>
                                                    <a class="btn btn-warning " style="width:100%; font-size:1vw" href="<?php echo e(url('/unset-coupon')); ?>">Xóa mã khuyến mãi</a>
                                                    <?php endif; ?>
                                                </form>
                                                <td>
                                                </td>
                                            </div> -->
                                        </div>
                                         <div class="col-lg-12 offset-lg-12">
                                            <div class="proceed-checkout">
                                                <ul>
                                                
                                                    <li class="cart-total">Tổng  <span> <?php echo e(number_format($total,0,',','.')); ?>Đ</span></li>
                                                    <input type="hidden" name="tong_tien" value="<?php echo e($total); ?>" readonly>

                                                    <li class="subtotal"> 
                                                    <?php if(Session::get('coupon')): ?>
                                                        <li>
                                                            
                                                                <?php $__currentLoopData = Session::get('coupon'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cou): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($cou['coupon_condition'] == 1): ?>
                                                                        Mã giảm : <?php echo e($cou['coupon_number']); ?>%
                                                                        <p>
                                                                            <?php 
                                                                            $total_coupon = ($total*$cou['coupon_number'])/100;
                                                                            ?>
                                                                        </p>
                                                                        <li class="cart-total">Tổng  <span> <?php echo e(number_format($total - $total_coupon,0,',','.')); ?>Đ</span></li>
                                                                        <input type="hidden" name="tong_tien" value="<?php echo e($total - $total_coupon); ?>" readonly>

                                                                    <?php elseif($cou['coupon_condition']==2): ?>
                                                                        Mã giảm : <?php echo e(number_format($cou['coupon_number'],0,',','.')); ?>đ
                                                                        <p>
                                                                            <?php 
                                                                            $total_coupon = $total - $cou['coupon_number'];
                                                                            ?>
                                                                        </p>														
                                                                        <li class="cart-total">Thanh toán  <span> <?php echo e(number_format($total_coupon,0,',','.')); ?>Đ</span></li>
                                                                        <input type="hidden" name="tong_tien" value="<?php echo e($total_coupon); ?>" readonly>

                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </li>
                                                    <?php endif; ?>
                                                            
                                                    
                                                    </li>
                                                </ul>
                                                <div class="order-btn">
                                                    <button type="submit" style="width:100%" class="site-btn place-btn ">Thanh toán</button>

                                                </div>
                                                 <!-- <a href="<?php echo e(route('checkout')); ?>" class="proceed-btn">Thanh toán</a>  -->
                                            </div>
                                        </div>
                                    </div> 
                                <!-- <div class="order-btn">
                                    <button type="submit" class="site-btn place-btn">Thanh toán</button>

                                </div> -->
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            
        </div>
    </section>
    <?php else: ?>
    <?php echo $__env->make('auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php endif; ?>
<!-- Shopping Cart Section End -->

<script type="">
    jQuery(document).ready(function($) {
        
    $('.choose').on('change', function() {
        var action = $(this).attr('id');
        var ma_id = $(this).val();
        var _token = $('input[name="_token"]').val();

        var result = '';

        if (action == 'city') {
            result = 'province';
        }
        else {
            result = 'wards';
        }
        $.ajax({
            url: '<?php echo e(url('/select-thanhpho')); ?>',
            method: 'post',
            data: {action: action, ma_id: ma_id, _token: _token},
            success: function(data) {
                $('#' + result).html(data);
            }
        });
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\datn\duanlrv\resources\views/site/checkout.blade.php ENDPATH**/ ?>